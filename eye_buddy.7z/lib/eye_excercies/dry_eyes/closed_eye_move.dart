import 'package:flutter/material.dart';

class ClosedEyeMove extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Center(
            child: Text(
              "Work In Progress...",
              style: TextStyle(fontSize: 20),
            ),
          ),
        ],
      ),
    );
  }
}
