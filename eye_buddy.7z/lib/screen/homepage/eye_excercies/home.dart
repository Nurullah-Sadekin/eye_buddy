import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:eye_buddy/screen/homepage/eye_excercies/share.dart';
import 'package:eye_buddy/screen/homepage/eye_excercies/profile.dart';
import 'package:flutter/material.dart';
import 'discover.dart';
import 'train.dart';
import 'package:eye_buddy/util/colorconfig.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // Properties & Variables needed

  int selectedIndex = 0;
  int currentTab = 0; // to keep track of active tab index
  final List<Widget> screens = [
    Discover(),
    Train(),
    Share(),
    Profile(),
  ];

  // to store nested tabs
// Our first view in viewport

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[selectedIndex],
      // floatingActionButton: GestureDetector(
      //   onTap: () {
      //     // Do Something
      //   },
      //   child: Container(
      //     decoration: BoxDecoration(
      //       image: DecorationImage(
      //         image: AssetImage('assets/icon/eye.png'),
      //       ),
      //       // borderRadius: BorderRadius.circular(0.50),
      //     ),
      //     width: 110,
      //     height: 94.68,
      //   ),
      // ),
      //  FloatingActionButton(
      //   elevation: 0.0,
      //   child: Image.asset("assets/icon/eye.png"),
      //   backgroundColor: Colors.transparent,
      //   onPressed: () {},
      // ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: ConvexAppBar(
          backgroundColor: colorFromHex('#181D3D'),
          color: colorFromHex('#FEC62D'),
          activeColor: colorFromHex('#FEC62D'),
          style: TabStyle.react,
          items: [
            TabItem(icon: Icons.search, title: 'Discover'),
            TabItem(icon: Icons.bubble_chart, title: 'Train'),
            TabItem(icon: Icons.casino_sharp, title: 'Share'),
            TabItem(icon: Icons.account_circle, title: 'Profile'),
          ],
          // initialActiveIndex: 1 /*optional*/,
          onTap: onItemTapped),
    );
  }

  void onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
  }
}

//     BottomAppBar(
//   color: colorFromHex(""),
//   shape: CircularNotchedRectangle(),
//   notchMargin: 10,
//   child: Container(
//     height: 60,
//     child: Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: <Widget>[
//         Row(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: <Widget>[
//             MaterialButton(
//               minWidth: 40,
//               onPressed: () {
//                 setState(() {
//                   currentScreen =
//                       Dashboard(); // if user taps on this dashboard tab will be active
//                   currentTab = 0;
//                 });
//               },
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   Icon(
//                     Icons.dashboard,
//                     color: currentTab == 0 ? Colors.blue : Colors.grey,
//                   ),
//                   Text(
//                     'Dashboard',
//                     style: TextStyle(
//                       color: currentTab == 0 ? Colors.blue : Colors.grey,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             MaterialButton(
//               minWidth: 40,
//               onPressed: () {
//                 setState(() {
//                   currentScreen =
//                       Chat(); // if user taps on this dashboard tab will be active
//                   currentTab = 1;
//                 });
//               },
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   Icon(
//                     Icons.chat,
//                     color: currentTab == 1 ? Colors.blue : Colors.grey,
//                   ),
//                   Text(
//                     'Chats',
//                     style: TextStyle(
//                       color: currentTab == 1 ? Colors.blue : Colors.grey,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),

//         // Right Tab bar icons

//         Row(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: <Widget>[
//             MaterialButton(
//               minWidth: 40,
//               onPressed: () {
//                 setState(() {
//                   currentScreen =
//                       Profile(); // if user taps on this dashboard tab will be active
//                   currentTab = 2;
//                 });
//               },
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   Icon(
//                     Icons.dashboard,
//                     color: currentTab == 2 ? Colors.blue : Colors.grey,
//                   ),
//                   Text(
//                     'Profile',
//                     style: TextStyle(
//                       color: currentTab == 2 ? Colors.blue : Colors.grey,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             MaterialButton(
//               minWidth: 40,
//               onPressed: () {
//                 setState(() {
//                   currentScreen =
//                       Settings(); // if user taps on this dashboard tab will be active
//                   currentTab = 3;
//                 });
//               },
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   Icon(
//                     Icons.chat,
//                     color: currentTab == 3 ? Colors.blue : Colors.grey,
//                   ),
//                   Text(
//                     'Settings',
//                     style: TextStyle(
//                       color: currentTab == 3 ? Colors.blue : Colors.grey,
//                     ),
//                   ),
//                 ],
//               ),
//             )
//           ],
//         )
//       ],
//     ),
//   ),
// ),
